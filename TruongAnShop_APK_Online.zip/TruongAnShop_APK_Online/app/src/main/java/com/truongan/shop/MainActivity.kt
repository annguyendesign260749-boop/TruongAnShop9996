package com.truongan.shop

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.storage.FirebaseStorage
import java.util.UUID

data class Product(
    val id: String = "", val name: String = "", val patternCode: String = "",
    val fabric: String = "", val consumption: String = "", val sizes: String = "",
    val cutting: String = "", val sewing: String = "", val finishing: String = "",
    val status: String = "", val imageUrl: String = "", val videoUrl: String = ""
) {
    fun toMap() = mapOf("name" to name, "patternCode" to patternCode, "fabric" to fabric,
        "consumption" to consumption, "sizes" to sizes, "cutting" to cutting,
        "sewing" to sewing, "finishing" to finishing, "status" to status,
        "imageUrl" to imageUrl, "videoUrl" to videoUrl,
        "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp())
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { MaterialTheme { ShopApp() } } }
}

@Composable
fun ShopApp() {
    val auth = remember { FirebaseAuth.getInstance() }
    val db = remember { FirebaseFirestore.getInstance() }
    var uid by remember { mutableStateOf(auth.currentUser?.uid) }
    var role by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Product?>(null) }
    var editing by remember { mutableStateOf(false) }
    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { uid = it.currentUser?.uid }
        auth.addAuthStateListener(listener)
        onDispose { auth.removeAuthStateListener(listener) }
    }
    DisposableEffect(uid) {
        role = ""; products = emptyList(); selected = null; editing = false
        var userSub: ListenerRegistration? = null
        var productSub: ListenerRegistration? = null
        if (uid != null) {
            userSub = db.collection("users").document(uid!!).addSnapshotListener { snap, ex ->
                if (ex != null) { error = ex.localizedMessage ?: "Không đọc được quyền" }
                else role = if (snap?.exists() == true) snap.getString("role") ?: "" else "none"
            }
            productSub = db.collection("products").addSnapshotListener { snap, ex ->
                if (ex != null) error = ex.localizedMessage ?: "Không tải được sản phẩm"
                else products = snap?.documents?.mapNotNull { d ->
                    try { Product(d.id, d.getString("name") ?: "", d.getString("patternCode") ?: "",
                        d.getString("fabric") ?: "", d.getString("consumption") ?: "",
                        d.getString("sizes") ?: "", d.getString("cutting") ?: "",
                        d.getString("sewing") ?: "", d.getString("finishing") ?: "",
                        d.getString("status") ?: "", d.getString("imageUrl") ?: "",
                        d.getString("videoUrl") ?: "") } catch (_: Exception) { null }
                } ?: emptyList()
            }
        }
        onDispose { userSub?.remove(); productSub?.remove() }
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("TRƯỜNG AN SHOP", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        if (uid == null) {
            LoginScreen { email, pass ->
                error = ""
                auth.signInWithEmailAndPassword(email.trim(), pass).addOnFailureListener { error = it.localizedMessage ?: "Đăng nhập thất bại" }
            }
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Tài khoản: ${if (role == "admin") "Quản lý" else if (role == "staff") "Nhân viên" else "Đang kiểm tra quyền"}")
                TextButton(onClick = { auth.signOut() }) { Text("Đăng xuất") }
            }
            if (role == "admin" || role == "staff") {
                if (editing && role == "admin") {
                    ProductEditor(selected, onCancel = { editing = false }, onSave = { product ->
                        error = ""
                        db.collection("products").document(product.id).set(product.toMap())
                            .addOnSuccessListener { editing = false; selected = null }
                            .addOnFailureListener { error = it.localizedMessage ?: "Lưu thất bại" }
                    })
                } else if (selected != null) {
                    ProductDetail(selected!!, role == "admin", onBack = { selected = null },
                        onEdit = { editing = true }, onDelete = {
                            db.collection("products").document(selected!!.id).delete()
                                .addOnSuccessListener { selected = null }
                                .addOnFailureListener { error = it.localizedMessage ?: "Xóa thất bại" }
                        })
                } else {
                    OutlinedTextField(query, { query = it }, label = { Text("Tìm mã hàng / tên sản phẩm") }, modifier = Modifier.fillMaxWidth())
                    if (role == "admin") Button(onClick = { selected = Product(); editing = true }) { Text("+ Thêm mã hàng") }
                    val filtered = products.filter { it.id.contains(query.trim(), true) || it.name.contains(query.trim(), true) }
                    Text("${filtered.size} sản phẩm")
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(filtered, key = { it.id }) { p ->
                            Card(onClick = { selected = p }, modifier = Modifier.fillMaxWidth()) {
                                Row(Modifier.padding(12.dp)) {
                                    if (p.imageUrl.isNotBlank()) AsyncImage(model = p.imageUrl, contentDescription = p.name, modifier = Modifier.size(72.dp))
                                    Spacer(Modifier.width(12.dp))
                                    Column { Text(p.id, fontWeight = FontWeight.Bold); Text(p.name); Text(p.status) }
                                }
                            }
                        }
                    }
                }
            } else if (role == "none") Text("Tài khoản chưa được cấp quyền. Nhờ quản lý tạo users/{uid} với role staff hoặc admin.")
            else CircularProgressIndicator()
        }
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
    }
}

@Composable
fun LoginScreen(onLogin: (String, String) -> Unit) {
    var email by remember { mutableStateOf("") }; var password by remember { mutableStateOf("") }
    OutlinedTextField(email, { email = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email))
    OutlinedTextField(password, { password = it }, label = { Text("Mật khẩu") }, modifier = Modifier.fillMaxWidth(), visualTransformation = PasswordVisualTransformation())
    Spacer(Modifier.height(8.dp))
    Button(onClick = { onLogin(email, password) }, enabled = email.isNotBlank() && password.isNotBlank()) { Text("Đăng nhập") }
}

@Composable
fun ProductDetail(p: Product, admin: Boolean, onBack: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    var confirmDelete by remember { mutableStateOf(false) }
    TextButton(onClick = onBack) { Text("← Danh sách") }
    Column(Modifier.verticalScroll(rememberScrollState())) {
        Text("${p.id} – ${p.name}", style = MaterialTheme.typography.titleLarge)
        if (p.imageUrl.isNotBlank()) AsyncImage(model = p.imageUrl, contentDescription = p.name, modifier = Modifier.fillMaxWidth().height(240.dp))
        listOf("Mã rập" to p.patternCode, "Loại vải" to p.fabric, "Định mức" to p.consumption,
            "Bảng size" to p.sizes, "Tổ cắt" to p.cutting, "Chuyền may" to p.sewing,
            "Hoàn thành" to p.finishing, "Trạng thái" to p.status, "Video (đường dẫn)" to p.videoUrl).forEach { (label, value) ->
            Text("$label: $value", modifier = Modifier.padding(vertical = 6.dp))
        }
        if (admin) {
            Button(onClick = onEdit) { Text("Sửa sản phẩm") }
            OutlinedButton(onClick = { confirmDelete = true }) { Text("Xóa sản phẩm") }
        }
    }
    if (confirmDelete) AlertDialog(onDismissRequest = { confirmDelete = false }, title = { Text("Xác nhận xóa?") },
        text = { Text("Mã hàng ${p.id} sẽ bị xóa khỏi cơ sở dữ liệu.") },
        confirmButton = { TextButton(onClick = { confirmDelete = false; onDelete() }) { Text("Xóa") } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Hủy") } })
}

@Composable
fun ProductEditor(original: Product?, onCancel: () -> Unit, onSave: (Product) -> Unit) {
    var id by remember(original) { mutableStateOf(original?.id ?: "") }
    var name by remember(original) { mutableStateOf(original?.name ?: "") }
    var pattern by remember(original) { mutableStateOf(original?.patternCode ?: "") }
    var fabric by remember(original) { mutableStateOf(original?.fabric ?: "") }
    var consumption by remember(original) { mutableStateOf(original?.consumption ?: "") }
    var sizes by remember(original) { mutableStateOf(original?.sizes ?: "") }
    var cutting by remember(original) { mutableStateOf(original?.cutting ?: "") }
    var sewing by remember(original) { mutableStateOf(original?.sewing ?: "") }
    var finishing by remember(original) { mutableStateOf(original?.finishing ?: "") }
    var status by remember(original) { mutableStateOf(original?.status ?: "") }
    var imageUrl by remember(original) { mutableStateOf(original?.imageUrl ?: "") }
    var videoUrl by remember(original) { mutableStateOf(original?.videoUrl ?: "") }
    var uploading by remember { mutableStateOf(false) }
    var uploadError by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            uploading = true; uploadError = ""
            val ref = FirebaseStorage.getInstance().reference.child("product-images/${UUID.randomUUID()}.jpg")
            ref.putFile(uri).continueWithTask { task ->
                if (!task.isSuccessful) throw task.exception ?: Exception("Upload failed")
                ref.downloadUrl
            }.addOnSuccessListener { imageUrl = it.toString(); uploading = false }
                .addOnFailureListener { uploadError = it.localizedMessage ?: "Tải ảnh thất bại"; uploading = false }
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("Thông tin mã hàng", style = MaterialTheme.typography.titleLarge)
        @Composable fun field(value: String, change: (String) -> Unit, label: String) {
            OutlinedTextField(value, change, label = { Text(label) }, modifier = Modifier.fillMaxWidth())
        }
        OutlinedTextField(id, { id = it.trim().uppercase() }, label = { Text("Mã hàng (bắt buộc)") }, modifier = Modifier.fillMaxWidth(), readOnly = original?.id?.isNotBlank() == true)
        field(name, { name = it }, "Tên sản phẩm (bắt buộc)")
        field(pattern, { pattern = it }, "Mã rập")
        field(fabric, { fabric = it }, "Loại vải")
        field(consumption, { consumption = it }, "Định mức nguyên phụ liệu")
        field(sizes, { sizes = it }, "Bảng size")
        field(cutting, { cutting = it }, "Thông tin tổ cắt")
        field(sewing, { sewing = it }, "Thông tin chuyền may")
        field(finishing, { finishing = it }, "Thông tin hoàn thành")
        field(status, { status = it }, "Trạng thái")
        field(videoUrl, { videoUrl = it }, "Link video HTTPS")
        if (imageUrl.isNotBlank()) AsyncImage(model = imageUrl, contentDescription = "Ảnh sản phẩm", modifier = Modifier.height(160.dp))
        OutlinedButton(onClick = { picker.launch("image/*") }, enabled = !uploading) { Text(if (uploading) "Đang tải ảnh..." else "Chọn ảnh từ điện thoại") }
        if (uploadError.isNotBlank()) Text(uploadError, color = MaterialTheme.colorScheme.error)
        Row {
            TextButton(onClick = onCancel) { Text("Hủy") }
            Button(onClick = { onSave(Product(id.trim(), name.trim(), pattern, fabric, consumption, sizes, cutting, sewing, finishing, status, imageUrl, videoUrl)) },
                enabled = id.matches(Regex("[A-Z0-9_-]{1,40}")) && name.isNotBlank() && !uploading) { Text("Lưu mã hàng") }
        }
    }
}
