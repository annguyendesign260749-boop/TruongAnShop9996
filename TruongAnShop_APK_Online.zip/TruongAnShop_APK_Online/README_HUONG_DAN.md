# TRƯỜNG AN SHOP — Android

## Chức năng
Đăng nhập email/mật khẩu; phân quyền admin/staff; tìm kiếm mã hàng/tên; xem thông tin tổ cắt, chuyền may, hoàn thành; thêm/sửa/xóa; chọn ảnh tải lên Firebase Storage; đồng bộ sản phẩm Firestore theo thời gian thực. Video hiện ở dạng liên kết văn bản (chưa tích hợp trình phát/quản lý upload video). Đây là phiên bản MVP, cần kiểm thử trước khi triển khai sản xuất.

## 1. Chuẩn bị
- Cài Android Studio (bản hỗ trợ Android Gradle Plugin 8.7.3), JDK 17, Android SDK 35.
- Mở thư mục dự án trong Android Studio; đợi Gradle sync.
- Nếu Android Studio yêu cầu Gradle wrapper, sử dụng Gradle 8.9 tương thích AGP 8.7.x; có thể tạo wrapper bằng `gradle wrapper --gradle-version 8.9` khi máy đã có Gradle.

## 2. Tạo Firebase
1. Vào https://console.firebase.google.com > Add project.
2. Add app > Android; package name **com.truongan.shop**.
3. Tải `google-services.json` và đặt vào thư mục **app/google-services.json** (không có sẵn trong ZIP vì là cấu hình riêng của bạn).
4. Authentication > Sign-in method > bật Email/Password.
5. Firestore Database > Create database; chọn khu vực phù hợp.
6. Storage > Get started; lưu ý Firebase Storage có thể yêu cầu gói thanh toán Blaze; xem chi phí trước khi bật.
7. Firestore > Rules: dán nội dung `firestore.rules` và Publish.
8. Storage > Rules: dán nội dung `storage.rules` và Publish.

## 3. Tạo tài khoản và cấp quyền
1. Authentication > Users > Add user: tạo email/mật khẩu cho quản lý và từng nhân viên.
2. Sao chép UID của từng tài khoản.
3. Firestore > Start collection `users` > Document ID = UID > field `role` kiểu string, giá trị `admin` cho quản lý hoặc `staff` cho nhân viên.
4. Chỉ người có quyền Firebase Console/Admin SDK mới cấp vai trò. Không cho ứng dụng tự tạo `admin`.
5. Tạo ít nhất một admin trước khi đăng nhập. Tài khoản không có role không được xem sản phẩm.

## 4. Chạy thử và build APK
1. File > Open > thư mục TruongAnShop_Android_Source.
2. Sync Project with Gradle Files; chấp nhận tải dependencies.
3. Kết nối điện thoại (bật Developer options > USB debugging) hoặc chọn Android Emulator.
4. Nhấn Run để kiểm thử đăng nhập, thêm mã, upload ảnh và tra cứu bằng tài khoản staff.
5. APK kiểm thử: Build > Build Bundle(s) / APK(s) > Build APK(s). File thường ở `app/build/outputs/apk/debug/app-debug.apk`.
6. APK phát hành: Build > Generate Signed Bundle / APK > APK > Create new keystore; lưu keystore và mật khẩu an toàn; chọn release > Create. File ở `app/build/outputs/apk/release/`.
7. Chép APK sang điện thoại, cho phép cài ứng dụng từ nguồn đó khi Android yêu cầu, sau đó mở và đăng nhập.

## 5. Lưu ý quan trọng
- Không chia sẻ file `google-services.json` như một bí mật mật khẩu, nhưng không đăng công khai thông tin quản trị Firebase hoặc private key.
- Ảnh dùng download URL; ai có URL token có thể xem ảnh dù Firestore/Storage rules hạn chế truy cập. Nếu ảnh nhạy cảm, chuyển sang tải ảnh bằng SDK với xác thực thay vì public token URL.
- Mã hàng dùng làm Firestore document ID. Không đổi mã hàng khi sửa, nếu không sẽ tạo mã mới; nên bổ sung kiểm tra trùng mã ở phiên bản tiếp theo.
- Xóa sản phẩm không tự xóa file ảnh trong Storage; cần quy trình dọn rác sau này.
- Firestore có bộ nhớ đệm cục bộ mặc định, nhưng app này được thiết kế ưu tiên online, chưa có chức năng quản lý offline đầy đủ.
- Trước triển khai: bổ sung kiểm thử quy tắc, sao lưu dữ liệu, xử lý lỗi mạng, phân trang, nhật ký chỉnh sửa, và khóa quyền trên Firebase Console.
- Môi trường hiện tại không có Android SDK/Gradle nên ZIP là **mã nguồn**, không phải APK đã biên dịch hay kiểm thử.
