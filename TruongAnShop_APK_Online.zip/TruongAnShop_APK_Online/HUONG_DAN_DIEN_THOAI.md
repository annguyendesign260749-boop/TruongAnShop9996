# TẠO APK TRƯỜNG AN SHOP – CHỈ DÙNG ĐIỆN THOẠI

**Tệp này là mã nguồn, chưa phải APK.** GitHub Actions sẽ biên dịch APK trên máy chủ; không cần máy tính hay Android Studio.

## A. Tạo Firebase (trên Chrome điện thoại, bật "Trang web cho máy tính" nếu khó thao tác)
1. Mở https://console.firebase.google.com → tạo dự án mới.
2. Thêm ứng dụng Android với **Package name: `com.truongan.shop`**.
3. Tải file `google-services.json` về điện thoại. Mở file bằng trình soạn thảo văn bản trên điện thoại và sao chép **toàn bộ nội dung JSON** để đưa vào GitHub Secret ở bước C. Không đưa mật khẩu hay service-account key vào repository.
4. Authentication → Sign-in method → bật **Email/Password**.
5. Firestore Database → Create database; chọn vùng dữ liệu phù hợp.
6. Storage → Get started (có thể yêu cầu nâng cấp Blaze / phát sinh phí). Nếu chưa bật Storage, tính năng ảnh sẽ chưa hoạt động.
7. Firestore → Rules: dán nội dung `firestore.rules` từ dự án, bấm Publish. Storage → Rules: dán `storage.rules`, bấm Publish.
8. Authentication → Users → Add user tạo tài khoản quản lý. Sao chép UID. Firestore → tạo collection `users`, document ID = UID, trường `role` kiểu string giá trị `admin`. Tương tự, mỗi nhân viên có tài khoản riêng và role `staff`.

## B. Đưa mã nguồn lên GitHub bằng điện thoại
1. Đăng ký/đăng nhập https://github.com, tạo repository **Private** tên `truong-an-shop`.
2. Trong repository, chọn **Code → Codespaces → Create codespace on main** (có thể phải bật giao diện desktop; Codespaces có giới hạn miễn phí/chi phí tùy tài khoản).
3. Trong giao diện Codespaces trên trình duyệt, chọn menu Explorer → Upload Files để tải **file ZIP dự án này** vào thư mục gốc (nếu trình duyệt không hỗ trợ kéo thả, dùng menu chuột phải / dấu ba chấm → Upload).
4. Mở Terminal của Codespaces, chạy các lệnh sau (đổi đúng tên file ZIP nếu cần):

```sh
unzip -o TruongAnShop_APK_Online.zip -d /tmp/truong-an
cp -a /tmp/truong-an/TruongAnShop_APK_Online/. .
rm TruongAnShop_APK_Online.zip
git add .
git commit -m "Tao ung dung Truong An Shop"
git push
```

Nếu GitHub Codespaces không khả dụng với tài khoản của bạn, cần dùng một môi trường GitHub khác hỗ trợ tải và giải nén ZIP; GitHub không tự biến file ZIP tải lên thành dự án.

## C. Cấu hình bí mật Firebase
1. Trên GitHub repository → **Settings → Secrets and variables → Actions → New repository secret**.
2. Name: `GOOGLE_SERVICES_JSON`.
3. Secret: dán **toàn bộ nội dung** file `google-services.json` từ Firebase (JSON nguyên bản, không cần base64).
4. Save. Không chia sẻ mật khẩu đăng nhập Firebase, GitHub hoặc private key với bất kỳ ai.

## D. Xuất và tải APK trên điện thoại
1. GitHub repository → tab **Actions** → workflow **Tao APK Truong An Shop**.
2. Nhấn **Run workflow** → Run workflow.
3. Chờ trạng thái xanh (Success). Nếu đỏ, mở log để xem lỗi; không nên coi APK là hoàn chỉnh khi chưa chạy thành công.
4. Mở lần chạy thành công → mục **Artifacts** → tải `TruongAnShop-APK` (file ZIP chứa `app-debug.apk`).
5. Giải nén ZIP trên điện thoại → mở `app-debug.apk` → cấp quyền cài ứng dụng từ nguồn này khi Android yêu cầu.
6. Đăng nhập bằng tài khoản Firebase đã cấp role. Thử thêm sản phẩm bằng tài khoản admin và tra cứu bằng tài khoản staff trên máy khác.

**Lưu ý:** APK tạo theo quy trình này là bản **debug để kiểm thử nội bộ**, không phải APK phát hành ký khóa riêng. Không đưa lên CH Play. Trước khi sử dụng thật, kiểm tra phân quyền, phí Firebase, quy trình sao lưu và dữ liệu nhạy cảm. Có thể phải chỉnh sửa mã nguồn nếu dịch vụ/phụ thuộc thay đổi.
